package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.service.DealOperationsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @Autowired
    private DealOperationsService dealOperationsService;


    @GetMapping("/api/foos")
    @ResponseBody
    public Item buyDeal(@RequestParam String dealId, @RequestParam String userId) {
        try {
            return dealOperationsService.buyDeal(dealId,userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
