package com.example.demo.model;

import java.sql.Time;

public class Deal {

    private Time startTime;
    private Time endTime;
    private Item item;
    private int maximumAllowedQuantity;
    private boolean isActive;

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public int getMaximumAllowedQuantity() {
        return maximumAllowedQuantity;
    }

    public void setMaximumAllowedQuantity(int maximumAllowedQuantity) {
        this.maximumAllowedQuantity = maximumAllowedQuantity;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
