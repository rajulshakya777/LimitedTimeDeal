package com.example.demo.service;

import com.example.demo.model.Deal;
import com.example.demo.model.Item;
import com.example.demo.repository.DealDatabase;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

public class DealOperationsService {

    //buy/claim the deal
    //create a deal
    //update itemcountin deal
    //update end Date

    /*
    Users cannot buy the deal if the deal time is over
    Users cannot buy if the maximum allowed deal has already been bought by other users.
    One user cannot buy more than one item as part of the deal.
     */

    @Autowired
    private DealDatabase dealDatabase;

    public Item buyDeal(String dealId, String userId) throws Exception{

         Map<String, Deal> dealIdVsDealMap = dealDatabase.getDealIdVsDealMap();

         Map<String, Deal> userIdVsDealMap = dealDatabase.getUserIdVsDealMap();

         //Map<String, String>

         Map<Deal, Integer> dealIntegerMap = dealDatabase.getDealPurchasedCount();

         Deal deal = dealIdVsDealMap.get(dealId);

         if(!deal.isActive()) {
             throw new Exception("Deal is exired");
         }else if(!userIdVsDealMap.get(userId).isActive()){
             throw new Exception("You can not buy more than one item as part of the deal");
         } else if(dealIntegerMap.get(deal) >= deal.getMaximumAllowedQuantity()) {
             throw new Exception("Max quanity purchased");
         } else {
             Integer val = dealIntegerMap.get(deal);
             dealIntegerMap.put(deal,val+1);
             userIdVsDealMap.get(userId).setActive(false);
             return dealIdVsDealMap.get(dealId).getItem();
         }


//         for(Map.Entry<String, Deal> dealEntry : dealIdVsDealMap.entrySet()) {
//
//             if(dealEntry.)
//
//         }


    }

}
