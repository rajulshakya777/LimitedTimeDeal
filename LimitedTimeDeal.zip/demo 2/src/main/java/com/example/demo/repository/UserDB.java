package com.example.demo.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserDB {

    private List<String> userIds;

    UserDB() {
        userIds = new ArrayList<>(Arrays.asList("u1","u2"));
    }

    public List<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }
}
