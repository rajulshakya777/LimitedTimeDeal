package com.example.demo.repository;

import com.example.demo.model.Deal;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public class DealDatabase {

    private Map<String, Deal> dealIdVsDealMap;
    private Map<String, Deal> userIdVsDealMap;
    private Map<Deal, Integer> dealPurchasedCount;

    public Map<Deal, Integer> getDealPurchasedCount() {
        return dealPurchasedCount;
    }

    public void setDealPurchasedCount(Map<Deal, Integer> dealPurchasedCount) {
        this.dealPurchasedCount = dealPurchasedCount;
    }

    public Map<String, Deal> getDealIdVsDealMap() {
        return dealIdVsDealMap;
    }

    public void setDealIdVsDealMap(Map<String, Deal> dealIdVsDealMap) {
        this.dealIdVsDealMap = dealIdVsDealMap;
    }

    public Map<String, Deal> getUserIdVsDealMap() {
        return userIdVsDealMap;
    }

    public void setUserIdVsDealMap(Map<String, Deal> userIdVsDealMap) {
        this.userIdVsDealMap = userIdVsDealMap;
    }
}
